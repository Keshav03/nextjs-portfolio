import React from 'react'
import {useState,useEffect} from 'react'
import { SocialIcon } from 'react-social-icons';
import Link from 'next/link';
import Image from 'next/image'

import { app, database } from '../../firebaseConfig';
import { collection, getDocs } from "firebase/firestore";

export default function Projects(props) {

    const [projects, setProjects] = useState([]);
    const dbInstance = collection(database, 'projects');
  
    useEffect(() => {
        const fetchProjects = async () => {
            await getDocs(dbInstance)
                .then((querySnapshot)=>{              
                    const newData = querySnapshot.docs
                        .map((doc) => ({...doc.data(), id:doc.id }));
                    setProjects(newData);                
                })
        }
        fetchProjects();
    });

    return (
      <div
        className="relative h-auto p-4  bg-[#000]/30 w-screen mx-auto flex flex-col justify-center items-center"
        id="project"
      >
        <div className="flex flex-col justify-evenly items-center w-1/5 p-1 m-5">
          <h4 className="text-white tracking-[0.5rem] text-xl uppercase p-2">
            Projects
          </h4>
          <hr className="h-[2px] w-[30%] bg-[#36bbc4] borderImageoutline-0" />
        </div>

        <div className=" flex justify-evenly items-evenly w-3/5 h-[750px] p-2 mt-10">
          {projects.map((project) => {
            return (
              <div className="relative h-[80%] w-1/4 bg-[#000]/30 overflow-hidden" key={project.id}>
                <div className="relative w-[100%] h-[150px]">
                    <Image 
                    alt=""
                    src={project.image}
                    layout='fill'
                    />
                </div>
                <h2 className="p-3 text-lg text-white font-medium tracking-[0.15rem]">
                  {project.name}
                </h2>
                <p className="text-xs p-3 text-[#fff]/70">
                  {project.descriptions}
                </p>

                <div className="w-[90%] p-2 flex flex-wrap ">
                  {project.tags.map((tag,index) => {
                    return (
                      <p className="p-1 bg-[#fff]/10 text-[#fff]/70 text-xs rounded m-1" key={index}>
                        {tag}
                      </p>
                    );
                  })}
                </div>

                <div className="absolute bottom-0 flex flex-row-reverse w-full ">
                  {project.links != "" ? (
                    <SocialIcon
                      url={project.links}
                      bgColor="transparent"
                      fgColor="#ffffff"
                    />
                  ) : null}

                  {project.github != "" ? (
                    <SocialIcon
                      url={project.github}
                      bgColor="transparent"
                      fgColor="#ffffff"
                    />
                  ) : null}
                </div>
              </div>
            );
          })}
        </div> 
      </div>
    );
}

