"use strict";
exports.id = 31;
exports.ids = [31];
exports.modules = {

/***/ 31:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ Modal)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


function Modal(props) {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "fixed z-20 bg-[#000]/60 top-0 left-0 w-[100vw] h-[100vh] flex flex-col justify-center items-center ",
        id: "modal",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "flex flex-col justify-center items-center bg-[#5a5a5a] w-2/5 h-[50vh]",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                    className: "relative text-[#36bbc4] tracking-[.75em] text-3xl font-bold uppercase text-center",
                    children: "Disclaimer"
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                    className: "relative tracking-[.75em] text-sm uppercase top-6 text-center p-6 text-white ",
                    children: "Website is still under development."
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                    id: "closeBtn",
                    className: "relative bg-[#f46d75] text-white w-1/5 top-10 pt-2 pb-2 pl-2 pr-2",
                    onClick: ()=>{
                        let modal = document.getElementById("modal");
                        modal.classList.add("hidden");
                    },
                    children: "Close"
                })
            ]
        })
    });
}


/***/ })

};
;