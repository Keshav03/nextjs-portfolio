/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  swcMinify: true,
}

module.exports = {
    images : {
      domains:["firebasestorage.googleapis.com","localhost.com"],
    },
}
